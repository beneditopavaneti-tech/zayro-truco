# ZAYRO TRUCO 2.0 — protótipo multiplayer

Requisitos: Node.js 20 ou superior. Não há dependências externas.

- `npm start` inicia o servidor na porta 3000 (ou PORT definida no ambiente).
- Abra http://localhost:3000 e crie uma sala. Compartilhe o convite com mais três jogadores. Para teste no mesmo computador, abra quatro perfis de navegador independentes.
- Para acesso por outros dispositivos, hospede o servidor Node em serviço com HTTPS. Em Render, por exemplo, crie um novo Web Service independente, com comando de build `npm install` e comando de start `npm start`.
- `npm test` executa teste de integração HTTP com quatro clientes.

O servidor mantém o estado e sorteia as cartas com aleatoriedade criptográfica. Cada sessão recebe somente suas cartas (e as do parceiro quando permitido na mão de 11); as cartas jogadas são públicas. A mão de ferro usa cartas ocultas. Cada jogador recebe token de sessão independente, armazenado na aba. Não existe API para ver ou manipular mãos online. O treino offline é a versão 1.3, com bots e painel local de montagem a cada três mãos.

Limitações: salas, mensagens e placares em memória, perdidos ao reiniciar o servidor; uma única instância; não há cadastro, banco de dados, recuperação de sessão perdida, substituição de jogadores desconectados, temporizador, ranking ou bots online. A partida começa quando quatro jogadores entram; avance manualmente após cada rodada. Sem dinheiro real. Protótipo sem revisão completa de segurança e sem teste visual em aparelhos físicos. Não use em competição oficial sem validar todas as regras, inclusive empates e mão de ferro, e proteção contra abuso. A publicação não faz parte deste ZIP.
