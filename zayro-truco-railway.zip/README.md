# ZAYRO TRUCO 2.0 — protótipo multiplayer

Requisitos: Node.js 20 ou superior. Não há dependências externas.

- `npm start` inicia o servidor na porta 3000 (ou PORT definida no ambiente).
- Abra http://localhost:3000 e crie uma sala. Compartilhe o convite com mais três jogadores. Para teste no mesmo computador, abra quatro perfis de navegador independentes.
- Para acesso por outros dispositivos, hospede o servidor Node em serviço com HTTPS. Em Render, por exemplo, crie um novo Web Service independente, com comando de build `npm install` e comando de start `npm start`.
- `npm test` executa teste de integração HTTP com quatro clientes.

O servidor mantém o estado e sorteia as cartas com aleatoriedade criptográfica. Cada sessão recebe somente suas cartas (e as do parceiro quando permitido na mão de 11); as cartas jogadas são públicas. A mão de ferro usa cartas ocultas. Cada jogador recebe token de sessão independente, armazenado na aba. Não existe API para ver ou manipular mãos online. O treino offline é a versão 1.3, com bots e painel local de montagem a cada três mãos.

Limitações: salas, mensagens e placares em memória, perdidos ao reiniciar o servidor; uma única instância; não há cadastro, banco de dados, recuperação de sessão perdida, substituição de jogadores desconectados, temporizador, ranking ou bots online. A partida começa quando quatro jogadores entram; avance manualmente após cada rodada. Sem dinheiro real. Protótipo sem revisão completa de segurança e sem teste visual em aparelhos físicos. Não use em competição oficial sem validar todas as regras, inclusive empates e mão de ferro, e proteção contra abuso. A publicação não faz parte deste ZIP.

## 2.1 — Salas personalizadas
O anfitrião pode escolher as 12 cartas e a vira antes da terceira mão completa (e 6ª, 9ª etc., contando por sala). Todos os participantes devem aceitar o modo e veem as cartas nas mãos personalizadas. O servidor valida a identidade do anfitrião e cartas duplicadas. Salas normais continuam aleatórias. Sem apostas.

## 2.2 — Modo narrador
Abra /narrador.html para criar uma sala de live sem ocupar vaga. Quatro jogadores entram pelo convite e precisam aceitar a transmissão; se a montagem personalizada estiver ativa, precisam aceitar também essa modalidade. O narrador vê as mãos originais, cartas restantes, vira, placar, vez de jogar e histórico de cartas da mão atual. O narrador pode montar cada terceira mão se essa opção foi marcada, mas não pode jogar. As mãos personalizadas ficam abertas a todos. O token de narrador não é incluído no convite. Não compartilhe a sessão com jogadores; use atraso na transmissão para evitar que vejam cartas durante o jogo. Não há transmissão de áudio ou vídeo integrada, nem recuperação de sessão ou histórico persistente. O estado é atualizado por consultas periódicas.

## 2.4 — Cadastro e acesso direto
Configure a variável ADMIN_PASSWORD no Railway (senha forte, exclusiva, 12 caracteres ou mais). Não inclua a senha no repositório. Abra /admin.html, entre, cadastre jogadores com nome, login e senha inicial (mínimo 8 caracteres). Abra a mesa de live pelo painel; o navegador abre /narrador.html com o token privado do narrador. Compartilhe apenas a URL principal com jogadores. Após login e concordância com a modalidade de transmissão, o jogador entra diretamente na mesa. Quatro vagas, uma por conta; nova autenticação recupera a mesma vaga e invalida o token anterior. As rotas antigas de criação/entrada são bloqueadas por padrão. Não configure ALLOW_LEGACY_ROOMS em produção.

Para persistência, crie um Volume no Railway montado em /data e configure DATA_DIR=/data. Os cadastros são gravados em players.json com hash scrypt e salt individual; sem volume o armazenamento local pode desaparecer no redeploy. Salas, sessões e placares continuam em memória; após reiniciar, admin deve abrir novamente a mesa e jogadores entrar novamente. Uma mesa ativa por instância; não há encerramento/reset de sala pelo admin, exclusão de contas ou recuperação de senha nesta versão. Não compartilhe a senha administrativa. O modo de live personalizado mantém consentimento e cartas abertas nas mãos personalizadas. Não há apostas. Testes HTTP locais com quatro clientes; UI em aparelhos reais e publicação ainda não verificadas. Use uma única réplica.
