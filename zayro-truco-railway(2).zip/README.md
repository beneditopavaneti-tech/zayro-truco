# ZAYRO TRUCO 2.4.3 — Cadastro e narração

Node.js 20 ou superior; sem dependências externas. `npm start` inicia o servidor (PORT ou 3000). `npm test` executa os testes HTTP de integração.

## Uso
Configure ADMIN_PASSWORD no Railway, com pelo menos 12 caracteres, sem incluir a senha no repositório. Abra /admin.html, entre, cadastre os jogadores com nome, login e senha inicial (mínimo 8 caracteres). Abra a mesa pelo painel para acessar /narrador.html. Compartilhe a URL principal com os jogadores. Login e senha levam diretamente à mesa, sem confirmação adicional. Quatro vagas, uma por conta; nova autenticação recupera a vaga e invalida o token anterior. As rotas antigas de criação/entrada são bloqueadas por padrão; não configure ALLOW_LEGACY_ROOMS em produção.

O servidor sorteia todas as mãos com aleatoriedade criptográfica. O narrador fica fora da mesa, com acesso somente de leitura às cartas originais e restantes, vira, placar e jogadas. Não há montagem de mãos. Os jogadores recebem somente suas cartas e as informações permitidas pelas regras. O token do narrador é privado; mantenha-o protegido. Recomenda-se informar os participantes sobre transmissões e usar atraso para impedir que assistam às cartas durante o jogo. Não há transmissão de áudio/vídeo integrada, nem apostas.

## Persistência e limites
Crie um volume Railway montado em /data e configure DATA_DIR=/data. Os cadastros são gravados em players.json com hash scrypt e salt individual. Cadastros anteriores continuam compatíveis; campos antigos de autorização não são usados. Sem volume, os cadastros podem desaparecer em reinicializações. Salas, sessões e placares permanecem em memória. Após reiniciar, abra a mesa novamente e peça aos jogadores que façam login. Uma mesa ativa por instância; use uma única réplica. Não há encerramento/reset de sala pelo admin, exclusão de contas ou recuperação de senha nesta versão. Protótipo sem revisão completa de segurança ou validação em aparelhos físicos.
