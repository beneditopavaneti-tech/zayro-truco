'use strict';
const fs=require('node:fs'),path=require('node:path'),{randomBytes,scryptSync,timingSafeEqual}=require('node:crypto');
const dir=process.env.DATA_DIR||path.join(__dirname,'data'),file=path.join(dir,'players.json');
let users=Object.create(null), current=null;const admins=new Map(), attempts=new Map();
if(fs.existsSync(file))Object.assign(users,JSON.parse(fs.readFileSync(file,'utf8')));
const token=()=>randomBytes(32).toString('hex');const digest=(pw,salt)=>scryptSync(pw,salt,64).toString('hex');
function same(a,b){let x=Buffer.from(a),y=Buffer.from(b);return x.length===y.length&&timingSafeEqual(x,y)}
function save(){fs.mkdirSync(dir,{recursive:true});let tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(users),{mode:0o600});fs.renameSync(tmp,file)}
function admin(req){let t=(req.headers.authorization||'').replace(/^Bearer /,'');let until=admins.get(t);if(!until||until<Date.now())return false;return true}
function rate(req,res,json){let ip=req.socket.remoteAddress,now=Date.now(),a=attempts.get(ip);if(!a||a.until<now){a={n:0,until:now+60000};attempts.set(ip,a)}if(++a.n>60){json(res,429,{error:'Muitas tentativas. Aguarde um minuto.'});return false}return true}
const norm=x=>String(x||'').trim().toLowerCase();
async function handle(req,res,url,b,ctx){let {json,rooms,newRoom,createPlayer}=ctx;let ep=url.pathname,post=req.method==='POST';if(!ep.startsWith('/api/account/')&&!ep.startsWith('/api/admin/'))return false;
const send=(status,data)=>{json(res,status,data);return true};
if(ep==='/api/admin/login'&&post){if(!rate(req,res,json))return true;let pw=process.env.ADMIN_PASSWORD;if(!pw||pw.length<12)return send(503,{error:'Configure ADMIN_PASSWORD com pelo menos 12 caracteres no Railway.'});if(typeof b.password!=='string'||b.password.length>256||!same(b.password,pw))return send(401,{error:'Senha inválida'});let t=token();for(let [k,v] of admins)if(v<Date.now())admins.delete(k);admins.set(t,Date.now()+12*3600000);return send(200,{token:t})}
if(ep.startsWith('/api/admin/')){if(!admin(req))return send(403,{error:'Entre como administrador'});
if(ep==='/api/admin/players'&&req.method==='GET')return send(200,{players:Object.entries(users).map(([login,u])=>({login,name:u.name})),room:current&&rooms.has(current.code)?{code:current.code,count:rooms.get(current.code).players.length}:null});
if(ep==='/api/admin/player'&&post){let login=norm(b.login),name=String(b.name||'').trim().slice(0,22),pw=b.password;if(!/^[a-z0-9_.-]{3,30}$/.test(login)||!name||typeof pw!=='string'||pw.length<8||pw.length>128)return send(400,{error:'Nome, login de 3–30 caracteres e senha de 8–128 caracteres.'});if(users[login])return send(409,{error:'Login já cadastrado'});let salt=token();users[login]={name,salt,hash:digest(pw,salt)};try{save()}catch(e){delete users[login];throw e}return send(200,{ok:true})}
if(ep==='/api/admin/room'&&post){if(current&&rooms.has(current.code))return send(200,{code:current.code,token:rooms.get(current.code).narratorToken,role:'narrator'});let r=newRoom({live:true});current={code:r.code};return send(200,{code:r.code,token:r.narratorToken,role:'narrator'})}
return send(404,{error:'Não encontrado'})}
if(ep==='/api/account/login'&&post){if(!rate(req,res,json))return true;let login=norm(b.login),u=users[login],pw=b.password;if(typeof pw!=='string'||pw.length>128||!u||!same(digest(pw,u.salt),u.hash))return send(401,{error:'Login ou senha incorretos'});let r=current&&rooms.get(current.code);if(!r)return send(409,{error:'Aguarde o administrador abrir a mesa.'});let p=r.players.findIndex(x=>x.login===login);if(p>=0){r.players[p].token=token();return send(200,{code:r.code,token:r.players[p].token,seat:p})}if(r.players.length>=4)return send(409,{error:'Mesa cheia. Aguarde uma vaga.'});let player=createPlayer(r,u.name);r.players[player.seat].login=login;return send(200,player)}
return send(404,{error:'Não encontrado'})}
module.exports={handle,admin};
